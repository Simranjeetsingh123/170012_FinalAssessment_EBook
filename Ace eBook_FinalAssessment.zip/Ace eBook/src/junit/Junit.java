package junit;

public class Junit {

}
